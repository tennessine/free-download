<?php
/*
Plugin Name: Menu Category Enhancer
Description: "Menu Category Enhancer" 是一个强大的 WordPress 插件，允许用户在现有菜单中轻松添加产品分类及其层级菜单项。通过简单的界面，用户可以选择要增强的菜单，并将所需的产品分类快速添加到菜单中，提升网站的导航结构和用户体验。适用于希望优化产品展示和导航的电商网站和内容丰富的网站。
Version: 1.0
Author: 微信：opengpt123
*/
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

// Hook to add menu item
add_action('admin_menu', 'my_select_plugin_menu');

function my_select_plugin_menu()
{
  add_options_page(
    'Menu Category Enhancer',          // Page title
    'Menu Category Enhancer',             // Menu title
    'manage_options',            // Capability
    'my-select-plugin',          // Menu slug
    'my_select_plugin_page',     // Function to display content
  );
}

function my_select_plugin_page()
{
  $menus = wp_get_nav_menus();
  ?>
  <div class="wrap">
    <h1><?php esc_html_e('Menu Category Enhancer', 'my-select-plugin'); ?></h1>
    <form method="post">
      <?php wp_nonce_field('my_select_plugin_action', 'my_select_plugin_nonce'); ?>
      <?php if (!empty($menus)): ?>
        <label for="my_select"><?php esc_html_e('Choose menu:', 'my-select-plugin'); ?></label>
        <select name="my_select" id="my_select">
          <?php foreach ($menus as $menu): ?>
            <option value="<?php echo esc_attr($menu->term_id); ?>"><?php echo esc_html($menu->name); ?></option>
          <?php endforeach; ?>
        </select>
        <?php submit_button(__('Create', 'my-select-plugin')); ?>
      <?php else: ?>
        请先创建菜单 Appearance > Menus
      <?php endif; ?>
    </form>
  </div>
  <?php
}

add_action('admin_init', 'my_select_plugin_handle_form');

function my_select_plugin_handle_form()
{
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    return;
  }
  if (!isset($_POST['my_select_plugin_nonce']) || !wp_verify_nonce($_POST['my_select_plugin_nonce'], 'my_select_plugin_action')) {
    return;
  }

  if (!isset($_POST['my_select'])) {
    return;
  }

  $selected_option = sanitize_text_field($_POST['my_select']);

  $menu_id = absint($selected_option);

  $product_categories = get_terms(
    array(
      'taxonomy' => 'product_cat',
      'hide_empty' => false,
    )
  );

  add_product_category_submenu(0, null, $menu_id, $product_categories);

  // update
  $menu = wp_get_nav_menu_object($selected_option);
  if (!$menu) {
    return;
  }
  ?>
  <div class="notice notice-success is-dismissible">
    <p><?php echo esc_html(sprintf(__('You have selected the menu: %s', 'my-select-plugin'), $menu->name)); ?></p>
  </div>
  <?php
}

function add_product_category_submenu($parent, $top_menu_id, $menu_id, $product_categories)
{
  foreach ($product_categories as $category) {
    if ($category->parent === $parent) {
      $category_link = get_term_link($category->term_id, 'product_cat');

      // Create a new submenu item for the category
      $submenu_item_data = array(
        'menu-item-object' => 'custom',
        'menu-item-title' => $category->name,
        'menu-item-url' => $category_link,
        'menu-item-status' => 'publish',
      );

      if ($top_menu_id) {
        $submenu_item_data['menu-item-parent-id'] = $top_menu_id;
      }

      $submenu_item_id = wp_update_nav_menu_item($menu_id, 0, $submenu_item_data);

      add_product_category_submenu($category->term_id, $submenu_item_id, $menu_id, $product_categories);
    }
  }
}