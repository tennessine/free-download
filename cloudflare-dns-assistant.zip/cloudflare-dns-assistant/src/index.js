import { render, useState, useEffect } from '@wordpress/element'
import {
  Panel,
  PanelBody,
  PanelRow,
  ToggleControl,
  TextControl,
  TextareaControl,
  Button,
  Icon,
} from '@wordpress/components'

import Modal from 'react-bootstrap/Modal'
import ProgressBar from 'react-bootstrap/ProgressBar'

import 'bootstrap/dist/css/bootstrap.min.css'

import apiFetch from '@wordpress/api-fetch'

function getCookie(name) {
  var matches = document.cookie.match(
    new RegExp(
      '(?:^|; )' +
        name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') +
        '=([^;]*)'
    )
  )

  return matches ? decodeURIComponent(matches[1]) : undefined
}

function setCookie(name, value, options) {
  options = options || {}

  var expires = options.expires

  if (typeof expires == 'number' && expires) {
    var d = new Date()
    d.setTime(d.getTime() + expires * 1000)
    expires = options.expires = d
  }
  if (expires && expires.toUTCString) {
    options.expires = expires.toUTCString()
  }

  value = encodeURIComponent(value)

  var updatedCookie = name + '=' + value

  for (var propName in options) {
    updatedCookie += '; ' + propName
    var propValue = options[propName]
    if (propValue !== true) {
      updatedCookie += '=' + propValue
    }
  }

  document.cookie = updatedCookie
}

function parseBooleanCookie(cookieValue, defaultValue) {
  if (cookieValue === undefined) return defaultValue
  return cookieValue.toLowerCase() === 'true'
}

function MyFirstApp() {
  const [email, setEmail] = useState(
    getCookie('cloudflare_dns_assistant_email') || ''
  )
  const [apikey, setApikey] = useState(
    getCookie('cloudflare_dns_assistant_apikey') || ''
  )
  const [domainsList, setDomainsList] = useState('')
  const [ip, setIP] = useState(getCookie('cloudflare_dns_assistant_ip') || '')

  const ipv6Default = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_ipv6'),
    false
  )
  const cacheDefault = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_cache'),
    false
  )
  const useHttpsDefault = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_useHttps'),
    false
  )
  const createWwwDefault = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_createWww'),
    true
  )
  const proxiedDefault = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_proxied'),
    true
  )
  const delRecordsDefault = parseBooleanCookie(
    getCookie('cloudflare_dns_assistant_delRecords'),
    true
  )

  const [delRecords, setDelRecords] = useState(delRecordsDefault)
  //禁用ipv6 默认false
  const [ipv6, setIPV6] = useState(ipv6Default)
  const [cache, setCache] = useState(cacheDefault)
  const [useHttps, setUseHttps] = useState(useHttpsDefault)
  const [createWww, setCreateWww] = useState(createWwwDefault)
  const [proxied, setProxied] = useState(proxiedDefault)

  const [modalShow, setModalShow] = useState(false)
  const openModal = () => setModalShow(true)
  const closeModal = () => setModalShow(false)

  const [progress, setProgress] = useState(0)
  const [animated, setAnimated] = useState(true)
  const [dialogTitle, setDialogTitle] = useState('请稍等，正在处理...')
  const [tableData, setTableData] = useState([])

  const handleClick = async () => {
    const isValidEmail =
      /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}$/.test(email)
    if (!isValidEmail) {
      alert('您的电子邮件 有误')
      return
    }

    const isValidKey = /^[a-f0-9]{32,48}$/.test(apikey)
    if (!isValidKey) {
      alert('您的 API 密钥 有误')
      return
    }

    const isValidIP =
      /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(
        ip
      )
    if (!isValidIP) {
      alert('IP 有误')
      return
    }

    const domainReg =
      /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$/i
    if (domainsList.trim().length === 0) {
      alert('域名为空')
      return
    }

    const domains = domainsList
      .trim()
      .split(/\s/)
      .filter((domain) => domain.trim().length > 0)

    for (const domain of domains) {
      if (domainReg.test(domain)) {
        console.log('valid domain', domain)
      } else {
        console.log('not valid domain', domain)
      }
    }

    openModal()
    const data = {
      email,
      apikey,
      domainsList,
      ip,
      delRecords,
      ipv6,
      cache,
      useHttps,
      createWww,
      proxied,
    }

    window.jQuery.ajax({
      url: myplugin_vars.api_url,
      headers: {
        Accept: 'application/json, */*;q=0.1',
      },
      method: 'POST',
      data,
      cache: false,
      dataType: 'json',
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-WP-Nonce', myplugin_vars.nonce)
        setAnimated(true)
        setProgress(0)
        setTableData([])
        setDialogTitle('请稍等，正在处理...')
      },
      xhrFields: {
        withCredentials: true,
        previous_text: '',
        onprogress: function (e) {
          var new_response = e.target.responseText.substring(
            e.target.previous_text.length
          )
          var result = JSON.parse(new_response)
          e.target.previous_text = e.target.responseText

          if (result.success === false) {
          } else {
            setTableData((prevTableData) => [...prevTableData, result])
            setProgress(result.progress)
          }
        },
      },
      complete: function (response) {
        if (response?.responseJSON?.success === false) {
          setDialogTitle(response?.responseJSON?.errors?.[0]?.message)
        } else {
          setAnimated(false)
          setDialogTitle('完成！')

          setCookie('cloudflare_dns_assistant_email', email, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_apikey', apikey, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_ip', ip, { expires: 2592000 })

          setCookie('cloudflare_dns_assistant_delRecords', delRecords, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_ipv6', ipv6, { expires: 2592000 })
          setCookie('cloudflare_dns_assistant_cache', cache, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_useHttps', useHttps, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_createWww', createWww, {
            expires: 2592000,
          })
          setCookie('cloudflare_dns_assistant_proxied', proxied, {
            expires: 2592000,
          })
        }
      },
    })
  }

  return (
    <>
      <Panel header="在Cloudflare中添加域名和DNS记录">
        <PanelBody>
          <TextControl
            placeholder="例如：example@mail.com"
            help="输入您的 Cloudflare 邮箱 https://dash.cloudflare.com/profile"
            label="您的电子邮件："
            value={email}
            onChange={setEmail}
          />
          <TextControl
            placeholder="例如：d249b90ceef68f9087c5b5efaca3957935b70"
            help="输入 Cloudflare 的全局 API 密钥 https://dash.cloudflare.com/profile/api-tokens"
            label="您的 API 密钥："
            value={apikey}
            onChange={setApikey}
          />
          <TextareaControl
            placeholder="例如：google.com"
            help="逐行输入域名列表"
            label="您的域名"
            rows={8}
            value={domainsList}
            onChange={setDomainsList}
          />
          <TextControl
            placeholder="例如：85.82.83.84"
            help="请输入服务器的 IP 地址（将为其添加 A 记录 DNS）"
            label="IP"
            value={ip}
            onChange={setIP}
          />
        </PanelBody>
        <PanelBody>
          <PanelRow>
            <ToggleControl
              label="创建www"
              checked={createWww}
              onChange={setCreateWww}
            />
            <ToggleControl
              label="Proxied"
              checked={proxied}
              onChange={setProxied}
            />
            <ToggleControl
              label="删除旧的 DNS 记录"
              checked={delRecords}
              onChange={setDelRecords}
            />
          </PanelRow>
          <PanelRow>
            <ToggleControl
              label="清除缓存"
              checked={cache}
              onChange={setCache}
            />
            <ToggleControl
              label="禁用 IPv6"
              checked={ipv6}
              onChange={setIPV6}
            />
            <ToggleControl
              label="始终使用 HTTPS"
              checked={useHttps}
              onChange={setUseHttps}
            />
          </PanelRow>
          <PanelRow>
            <Button variant="primary" onClick={handleClick}>
              批量创建
            </Button>
          </PanelRow>
        </PanelBody>
      </Panel>
      <Modal show={modalShow} scrollable centered>
        <Modal.Header>
          <Modal.Title>{dialogTitle}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <ProgressBar
            label={`${progress}%`}
            animated={animated}
            now={progress}
          />
          <div className="modal-result">
            {tableData.map((data, tableIndex) => {
              return (
                <table className="table" key={tableIndex}>
                  <thead>
                    <tr>
                      <th scope="col">域名 {data.domain}</th>
                      <th scope="col">状态</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(data).map(([key, value], trIndex) => {
                      if (
                        ['progress', 'name_servers', 'domain'].includes(key)
                      ) {
                        return null
                      }
                      return (
                        <tr key={trIndex}>
                          <td>{key}</td>
                          <td className="status">
                            {value ? (
                              <Icon icon="yes" style={{ color: '#28a745' }} />
                            ) : (
                              <Icon icon="no" style={{ color: '#dc3545' }} />
                            )}
                          </td>
                        </tr>
                      )
                    })}
                    {data.name_servers && (
                      <tr>
                        <td colSpan={2}>NS: {data.name_servers.join(', ')}</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              )
            })}
          </div>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            关闭
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

window.addEventListener(
  'load',
  function () {
    render(<MyFirstApp />, document.querySelector('#my-first-gutenberg-app'))
  },
  false
)
