<?php
/**
 * Plugin Name: Cloudflare DNS Assistant
 * Version: 1.0
 * Author: 微信：opengpt123
 * Description: Cloudflare DNS助手插件简化了您直接从WordPress仪表板管理Cloudflare DNS记录的过程。通过用户友好的界面，该插件使您能够轻松地添加、编辑和删除DNS记录，而无需离开您的网站。
 */

add_action('admin_menu', 'my_admin_menu');

function my_admin_menu()
{
  add_management_page(
    'Cloudflare DNS Assistant',
    'Cloudflare DNS Assistant',
    'manage_options',
    'cloudflare-dns-assistant',
    function () {
      echo '<div id="my-first-gutenberg-app"></div>';
    }
  );
}

add_action('admin_enqueue_scripts', 'load_custom_wp_admin_scripts');

function load_custom_wp_admin_scripts($hook)
{
  if ('tools_page_cloudflare-dns-assistant' !== $hook) {
    return;
  }

  $asset_file = include plugin_dir_path(__FILE__) . 'build/index.asset.php';
  foreach ($asset_file['dependencies'] as $style) {
    wp_enqueue_style($style);
  }

  if (!in_array('jquery', $asset_file['dependencies'])) {
    array_push($asset_file['dependencies'], 'jquery');
  }

  //build/index.js
  wp_register_script(
    'my-first-gutenberg-app',
    plugins_url('build/index.js', __FILE__),
    $asset_file['dependencies'],
    $asset_file['version']
  );
  wp_enqueue_script('my-first-gutenberg-app');

  wp_localize_script(
    'my-first-gutenberg-app',
    'myplugin_vars',
    array(
      'api_url' => rest_url('cloudflare/v1/manage/'),
      'nonce' => wp_create_nonce('wp_rest'),
    )
  );

  //build/index.css
  wp_register_style(
    'index',
    plugins_url('build/index.css', __FILE__),
    array(),
    $asset_file['version']
  );
  wp_enqueue_style('index');

  wp_register_style(
    'my-first-gutenberg-app',
    plugins_url('style.css', __FILE__),
    array(),
    $asset_file['version']
  );
  wp_enqueue_style('my-first-gutenberg-app');
}

add_action('rest_api_init', 'wp_learn_register_routes');
function wp_learn_register_routes()
{
  register_rest_route(
    'cloudflare/v1',
    '/manage/',
    array(
      'methods' => 'POST',
      'callback' => 'cloudflare_manage',
      'permission_callback' => function () {
        return current_user_can('manage_options');
      },
    ),
  );
}

function cloudflare_manage($request)
{
  header('Cache-Control: no-cache');
  header('X-Accel-Buffering: no');

  set_time_limit(0);
  ob_implicit_flush(true);
  ob_end_flush();


  $email = sanitize_email($request['email']);
  $apikey = sanitize_text_field($request['apikey']);
  $domainsList = sanitize_text_field($request['domainsList']);
  $ip = sanitize_text_field($request['ip']);

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    return new WP_Error(10001, 'email有误');
  }

  if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    return new WP_Error(10001, 'IP有误');
  }

  $delRecords = filter_var($request['delRecords'], FILTER_VALIDATE_BOOLEAN);
  $ipv6 = filter_var($request['ipv6'], FILTER_VALIDATE_BOOLEAN);
  $cache = filter_var($request['cache'], FILTER_VALIDATE_BOOLEAN);
  $useHttps = filter_var($request['useHttps'], FILTER_VALIDATE_BOOLEAN);
  $createWww = filter_var($request['createWww'], FILTER_VALIDATE_BOOLEAN);
  $proxied = filter_var($request['proxied'], FILTER_VALIDATE_BOOLEAN);

  $domains = preg_split("/\s/", $domainsList);

  // Common headers for API requests
  $headers = array(
    'X-Auth-Email' => $email,
    'X-Auth-Key' => $apikey,
    'Content-Type' => 'application/json',
  );

  // Get Account ID
  $url = 'https://api.cloudflare.com/client/v4/accounts?page=1&per_page=20&direction=desc';
  $json = make_api_request($url, 'GET', $headers);

  if (is_wp_error($json) || !$json['success']) {
    return $json;
  }

  $accountId = $json['result'][0]['id'];

  $totalDomains = count($domains);
  $lastIndex = $totalDomains - 1;

  foreach ($domains as $index => $domain) {

    if ($index === $lastIndex) {
      $progress = 100;
    } else {
      $progress = intval((($index + 1) * 100) / $totalDomains);
    }

    $return = array(
      'domain' => $domain,
      'progress' => $progress,
    );

    // List Zones
    $url = add_query_arg(array('name' => $domain), 'https://api.cloudflare.com/client/v4/zones');
    $json = make_api_request($url, 'GET', $headers);
    if (is_wp_error($json)) {
      return $json;
    }

    $return['List Zones'] = true;

    // Check if the zone exists, otherwise create it
    if (empty($json['result'])) {
      $url = 'https://api.cloudflare.com/client/v4/zones';
      $body = array(
        'account' => array('id' => $accountId),
        'name' => $domain,
        'type' => 'full'
      );
      $json = make_api_request($url, 'POST', $headers, $body);
      if (is_wp_error($json)) {
        return $json;
      }

      $return['Create Zone'] = $json['success'];

      if ($json['success'] === false) {
        outputJsonWithFlush($return);
        continue;
      }

      $zone_identifier = $json['result']['id'];
      $name_servers = $json['result']['name_servers'];
    } else {
      $zone_identifier = $json['result'][0]['id'];
      $name_servers = $json['result'][0]['name_servers'];
    }

    if ($ipv6) {
      changeIPv6setting($headers, $zone_identifier, 'off');
      $return['ipv6 off'] = true;
    }

    if ($useHttps) {
      changeAlwaysUseHTTPSsetting($headers, $zone_identifier, 'on');
      $return['always use https'] = true;
    }

    if ($cache) {
      purge_cache($headers, $zone_identifier);
      $return['purge cache'] = true;
    }

    // List DNS Records
    $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/dns_records';
    $json = make_api_request($url, 'GET', $headers);
    if (is_wp_error($json)) {
      return $json;
    }

    $return['List DNS Records'] = true;

    $domainArray = generateDomainArray($domain, $createWww);

    foreach ($json['result'] as $record) {
      if ($delRecords || in_array($record['name'], $domainArray)) {
        // Delete DNS Record
        $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/dns_records/' . $record['id'];
        $json = make_api_request($url, 'DELETE', $headers);
        if (is_wp_error($json)) {
          return $json;
        }

        if (substr($record['name'], 0, 4) === 'www.') {
          $return['Delete DNS Record www'] = true;
        } else {
          $return['Delete DNS Record'] = true;
        }
      }
    }

    foreach ($domainArray as $domain) {
      $json = createDNSRecond($headers, $zone_identifier, $ip, $domain, $proxied);
      if (is_wp_error($json)) {
        return $json;
      }

      if (substr($domain, 0, 4) === 'www.') {
        $return['Create DNS Record www'] = true;
      } else {
        $return['Create DNS Record'] = true;
      }
    }

    $return['name_servers'] = $name_servers;

    outputJsonWithFlush($return);
  }
}

function outputJsonWithFlush($return)
{
  echo json_encode($return);
  if (ob_get_level() > 0) {
    ob_flush();
  }
  flush();
}

function generateDomainArray($domain, $createWww)
{
  // Initialize the array with the original domain
  $domains = [$domain];

  // Define known double suffixes
  $doubleSuffixes = ['com.cn', 'net.cn', 'org.cn'];

  // Split the domain into parts
  $parts = explode('.', $domain);
  $numParts = count($parts);

  // Determine the suffix and main domain parts
  $suffix = implode('.', array_slice($parts, -2, 2));
  $isDoubleSuffix = in_array($suffix, $doubleSuffixes);

  // Check if the domain is a subdomain
  if ($createWww) {
    if ($numParts == 2 || ($isDoubleSuffix && $numParts == 3)) {
      // Only add www for root domains with two parts, or known double suffix domains with three parts
      $domains[] = 'www.' . $domain;
    }
  }

  // Return the array of domains
  return $domains;
}

// Helper function for making API requests
function make_api_request($url, $method = 'GET', $headers = [], $body = null)
{
  $args = array(
    'method' => $method,
    'headers' => $headers,
  );
  if ($body) {
    $args['body'] = json_encode($body);
  }
  $response = wp_remote_request($url, $args);
  if (is_wp_error($response)) {
    $error_code = wp_remote_retrieve_response_code($response);
    $error_message = wp_remote_retrieve_response_message($response);
    return new WP_Error($error_code, $error_message);
  }
  return json_decode(wp_remote_retrieve_body($response), true);
}

function createDNSRecond($headers, $zone_identifier, $ip, $domain, $proxied)
{
  // Create DNS Record
  $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/dns_records';
  $body = array(
    'content' => $ip,
    'name' => $domain,
    'proxied' => $proxied,
    'type' => 'A'
  );
  $json = make_api_request($url, 'POST', $headers, $body);
  if (is_wp_error($json)) {
    return $json;
  }
  return $json;
}

function changeIPv6setting($headers, $zone_identifier, $value)
{
  $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/settings/ipv6';
  $body = array(
    'value' => $value,
  );
  $json = make_api_request($url, 'PATCH', $headers, $body);
  if (is_wp_error($json)) {
    return $json;
  }
  return $json;
}

function changeAlwaysUseHTTPSsetting($headers, $zone_identifier, $value)
{
  $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/settings/always_use_https';
  $body = array(
    'value' => $value,
  );
  $json = make_api_request($url, 'PATCH', $headers, $body);
  if (is_wp_error($json)) {
    return $json;
  }
  return $json;
}

function purge_cache($headers, $zone_identifier)
{
  $url = 'https://api.cloudflare.com/client/v4/zones/' . $zone_identifier . '/purge_cache';
  $body = array(
    'purge_everything' => true,
  );
  $json = make_api_request($url, 'POST', $headers, $body);
  if (is_wp_error($json)) {
    return $json;
  }
  return $json;
}